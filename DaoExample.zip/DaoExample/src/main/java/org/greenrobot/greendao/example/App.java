package org.greenrobot.greendao.example;

import android.app.Application;

import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.example.dao.DaoMaster;
import org.greenrobot.greendao.example.dao.DaoSession;
import org.greenrobot.greendao.example.db.CYOpenHelper;

public class App extends Application {

    private DaoSession daoSession;

    @Override
    public void onCreate() {
        super.onCreate();


        CYOpenHelper helper = new CYOpenHelper(this);
        Database db = helper.getWritableDb();
        daoSession = new DaoMaster(db).newSession();
    }


    public DaoSession getDaoSession() {
        return daoSession;
    }
}
