package org.greenrobot.greendao.example.db;

import android.app.Activity;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.example.dao.DaoSession;
import org.greenrobot.greendao.example.model.Note;

/**
 * Authority: ciyun
 * Date: 2018-04-20  17:01
 */

public class NoteDaoManager extends BaseDaoManager<Note> {

    public NoteDaoManager(Activity context) {
        super(context);
    }

    @Override
    AbstractDao getDao(DaoSession daoSession) {

        AbstractDao noteDao = daoSession.getNoteDao();
        return noteDao;
    }
}
