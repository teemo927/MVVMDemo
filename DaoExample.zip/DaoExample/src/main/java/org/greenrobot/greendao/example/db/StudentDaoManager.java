package org.greenrobot.greendao.example.db;

import android.app.Activity;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.example.dao.DaoSession;
import org.greenrobot.greendao.example.model.Student;

/**
 * Authority: ciyun
 * Date: 2018-04-20  17:06
 */

public class StudentDaoManager extends BaseDaoManager<Student> {
    public StudentDaoManager(Activity context) {
        super(context);
    }

    @Override
    AbstractDao getDao(DaoSession daoSession) {
        return daoSession.getStudentDao();
    }
}
