package org.greenrobot.greendao.example.db;

import android.app.Activity;

import org.greenrobot.greendao.AbstractDao;
import org.greenrobot.greendao.example.App;
import org.greenrobot.greendao.example.dao.DaoSession;
import org.greenrobot.greendao.query.Query;

import java.util.List;

/**
 * Authority: ciyun
 * Date: 2018-04-20  11:36
 */

public abstract class BaseDaoManager<T> {

    private AbstractDao abstractDao;

    BaseDaoManager(Activity context) {
//        CYOpenHelper helper = new CYOpenHelper(context);
//        Database db = helper.getWritableDb();
//        DaoSession daoSession = new DaoMaster(db).newSession();
        DaoSession daoSession = ((App)context.getApplication()).getDaoSession();
        // get the note DAO
        abstractDao = getDao(daoSession);
    }

    public void loadAll() {
        abstractDao.loadAll();
    }

    public List<T> query() {
        // query all notes, sorted a-z by their text 排序
        Query<T> allQuery = abstractDao.queryBuilder().build();
        return allQuery.list();
    }

    public long insert(T data) {
        return abstractDao.insert(data);
    }

    public void deleteByKey(long key) {
        abstractDao.deleteByKey(key);
    }

    public void deleteAll() {
        abstractDao.deleteAll();
    }

    public void update(T data) {
        abstractDao.update(data);
    }


    abstract AbstractDao getDao(DaoSession daoSession);
}
