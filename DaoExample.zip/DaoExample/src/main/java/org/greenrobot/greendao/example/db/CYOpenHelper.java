package org.greenrobot.greendao.example.db;

import android.content.Context;
import android.util.Log;

import org.greenrobot.greendao.database.Database;
import org.greenrobot.greendao.example.dao.DaoMaster;
import org.greenrobot.greendao.example.dao.DaoSession;
import org.greenrobot.greendao.example.dao.NoteDao;
import org.greenrobot.greendao.example.dao.StudentDao;

public class CYOpenHelper extends DaoMaster.OpenHelper {

    private static DaoMaster daoMaster;
    private static DaoSession daoSession;

    //TODO 数据库名字
    public static final String DBNAME = "greendao.db";

    public CYOpenHelper(Context context) {
        super(context, DBNAME);
    }

    @Override
    public void onUpgrade(Database db, int oldVersion, int newVersion) {
        super.onUpgrade(db, oldVersion, newVersion);
        Log.i("greenDAO", "Upgrading schema from version " + oldVersion + " to " + newVersion + " by dropping all tables");

        //操作数据库的更新
        // switch语句在每个case中没有break？？？ 这是为了保证跨版本升级的时候每次数据库的升级都会执行到
        switch (oldVersion) {

            case 1:
                MigrationHelper.migrate(db, NoteDao.class);

            case 2:
                MigrationHelper.migrate(db, NoteDao.class);

            case 3:
                MigrationHelper.migrate(db, NoteDao.class);

            case 4:
                MigrationHelper.migrate(db, StudentDao.class);

            case 5:
                MigrationHelper.migrate(db, NoteDao.class);
                MigrationHelper.migrate(db, StudentDao.class);

            default:
        }
    }

    /**
     * 取得DaoMaster
     *
     * @param context
     * @return
     */
    public static DaoMaster getDaoMaster(Context context) {
        if (daoMaster == null) {
            DaoMaster.OpenHelper helper = new CYOpenHelper(context);
            daoMaster = new DaoMaster(helper.getWritableDatabase());
        }
        return daoMaster;
    }

    /**
     * 取得DaoSession
     *
     * @param context
     * @return
     */
    public static DaoSession getDaoSession(Context context) {
        if (daoSession == null) {
            if (daoMaster == null) {
                daoMaster = getDaoMaster(context);
            }
            daoSession = daoMaster.newSession();
        }
        return daoSession;
    }
}